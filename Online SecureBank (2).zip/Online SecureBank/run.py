import os
import sys
sys.path.append('C:Online SecureBank')
from app.init0 import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
